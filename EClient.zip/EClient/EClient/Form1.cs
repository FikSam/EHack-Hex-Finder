﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Memory;


namespace EClient
{
    public partial class Form1 : Form
    {
        public Mem m = new Mem();

        public Form1()
        {
            InitializeComponent();
        }


        private async void Inject_Click(object sender, EventArgs e)
        {
            string processName = process.Text;
            string findhex = find.Text;
            string edithex = edit.Text;

            int procIdFromName = this.m.GetProcIdFromName(processName);
            if (procIdFromName > 0)
            {
                this.m.OpenProcess(procIdFromName);
                IEnumerable<long> aobscanresults = await this.m.AoBScan(findhex, true, true, "");

                if (aobscanresults != null && aobscanresults.Any())
                {
                    long Singleaobscanresult = aobscanresults.FirstOrDefault();
                    this.m.WriteMemory(Singleaobscanresult.ToString("X"), "bytes", edithex, "", (Encoding)null, true);
                    int num = (int)MessageBox.Show("Успешно!");
                }
                else
                {
                    int num = (int)MessageBox.Show("Адрес не найден");
                }
            }
            else
            {
                MessageBox.Show("Ошибка: Процесс не найден!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void info_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Информация: Program by @destroyhackes\n-----\nИнструкция:\nВ Поле <Поиск> вставте ваш Hex \nВ Поле <Замена> вставте Hex для замены \nВ Поле <Процесс> введите имя процесса с .exe", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
