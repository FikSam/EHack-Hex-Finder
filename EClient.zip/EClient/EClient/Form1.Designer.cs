﻿namespace EClient
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Inject = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.find = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.edit = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.process = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.info = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Inject
            // 
            this.Inject.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(155)))), ((int)(((byte)(94)))));
            this.Inject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Inject.Font = new System.Drawing.Font("Verdana", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inject.Location = new System.Drawing.Point(278, 171);
            this.Inject.MaximumSize = new System.Drawing.Size(193, 86);
            this.Inject.MinimumSize = new System.Drawing.Size(193, 86);
            this.Inject.Name = "Inject";
            this.Inject.Size = new System.Drawing.Size(193, 86);
            this.Inject.TabIndex = 0;
            this.Inject.Text = "START";
            this.Inject.UseVisualStyleBackColor = false;
            this.Inject.Click += new System.EventHandler(this.Inject_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(224)))), ((int)(((byte)(65)))));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "EClient";
            // 
            // find
            // 
            this.find.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.find.ForeColor = System.Drawing.SystemColors.Info;
            this.find.Location = new System.Drawing.Point(22, 67);
            this.find.Name = "find";
            this.find.Size = new System.Drawing.Size(292, 20);
            this.find.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(19, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "SERACH / ПОИСК";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(19, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "EDIT: / ЗАМЕНИТЬ НА:";
            // 
            // edit
            // 
            this.edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.edit.ForeColor = System.Drawing.SystemColors.Info;
            this.edit.Location = new System.Drawing.Point(22, 106);
            this.edit.Name = "edit";
            this.edit.Size = new System.Drawing.Size(292, 20);
            this.edit.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(19, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "PROCESS: / ПРОЦЕСС:";
            // 
            // process
            // 
            this.process.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.process.ForeColor = System.Drawing.SystemColors.Info;
            this.process.Location = new System.Drawing.Point(22, 237);
            this.process.Name = "process";
            this.process.Size = new System.Drawing.Size(233, 20);
            this.process.TabIndex = 7;
            this.process.Text = "HD-Player.exe";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label5.Location = new System.Drawing.Point(127, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "v1.0.4";
            // 
            // info
            // 
            this.info.BackgroundImage = global::EClient.Properties.Resources.info2;
            this.info.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.info.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.info.Location = new System.Drawing.Point(427, 9);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(44, 44);
            this.info.TabIndex = 9;
            this.info.UseVisualStyleBackColor = true;
            this.info.Click += new System.EventHandler(this.info_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.ClientSize = new System.Drawing.Size(483, 269);
            this.Controls.Add(this.info);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.process);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.edit);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.find);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Inject);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(499, 308);
            this.MinimumSize = new System.Drawing.Size(499, 308);
            this.Name = "Form1";
            this.Text = "EClient | Main";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Inject;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox find;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox edit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox process;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button info;
    }
}

